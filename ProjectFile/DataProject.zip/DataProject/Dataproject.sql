
SHOW Tables;


