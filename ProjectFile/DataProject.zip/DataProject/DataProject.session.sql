INSERT INTO Insurance_Policies (Policy_Name, Policy_Type, Premium, Coverage_Amount, Start_Date, End_Date, Terms_Conditions, User_ID)
VALUES 
('Health Coverage', 'Health', 500, 20000, '2024-01-01', '2025-01-01', 'Standard health coverage terms and conditions', 6),
('Auto Insurance', 'Auto', 300, 15000, '2024-05-15', '2025-05-15', 'Auto insurance policy terms and conditions', 6),
('Home Insurance', 'Home', 400, 30000, '2024-06-01', '2025-06-01', 'Home insurance policy terms and conditions', 6);

