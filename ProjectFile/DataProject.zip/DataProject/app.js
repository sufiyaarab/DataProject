const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const emailjs = require('emailjs-com'); // Ensure this is installed and configured correctly
const db = require('./db');
const app = express();





app.use(express.json());
app.use(express.static('public'));
app.use('/locales', express.static('locales'));

const PORT = 3001;

// Configure express-session
app.use(session({
    secret: 'mIqdqG289YXmNoaNk04X2', // Replace with a strong secret key
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false } // Set to true if using HTTPS
}));

// Basic route to check server status
app.get('/', (req, res) => {
    res.send('Server is running and connected to the database!');
});

// Signup route
app.post('/api/signup', async (req, res) => {
    const { first_name, last_name, dob, email, phone_number, street, zip, city, province, password } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const query = `
            INSERT INTO Users 
            (First_Name, Last_Name, DOB, Email, Phone_Number, Street, Zip, City, Province, Password) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        const values = [first_name, last_name, dob, email, phone_number, street, zip, city, province, hashedPassword];

        db.query(query, values, (err, result) => {
            if (err) {
                console.error('Error creating user:', err);
                return res.status(500).json({ message: 'Error creating user' });
            }
            req.session.userId = result.insertId; // Save the new user ID to the session
            res.status(201).json({ message: 'User created successfully', redirect: '/setup-security-questions.html' });
        });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});


// Login route
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    const query = 'SELECT * FROM Users WHERE Email = ?';

    db.query(query, [email], async (err, results) => {
        if (err) {
            console.error('Error fetching user:', err);
            return res.status(500).json({ message: 'Error fetching user' });
        }

        if (results.length > 0) {
            const user = results[0];
            const passwordMatch = await bcrypt.compare(password, user.Password);

            if (passwordMatch) {
                req.session.userId = user.User_ID; // Store User_ID in the session
                res.json({ message: 'Login successful' });
            } else {
                res.status(401).json({ message: 'Invalid credentials' });
            }
        } else {
            res.status(401).json({ message: 'Invalid credentials' });
        }
    });
});

// Logout route
app.post('/api/logout', (req, res) => {
    if (req.session) {
        req.session.destroy((err) => {
            if (err) {
                console.error("Error during logout:", err);
                return res.status(500).json({ message: 'Logout failed' });
            }
            res.clearCookie('connect.sid');
            res.json({ message: 'Logged out successfully' });
        });
    } else {
        res.status(400).json({ message: 'No active session to log out' });
    }
});

// Middleware to protect routes
function isAuthenticated(req, res, next) {
    if (req.session.userId) {
        return next();
    } else {
        res.status(401).json({ message: 'Unauthorized' });
    }
}

// Route to get user-specific profile data
app.get('/api/profile', isAuthenticated, (req, res) => {
    db.query('SELECT * FROM Users WHERE User_ID = ?', [req.session.userId], (err, results) => {
        if (err) {
            console.error('Error fetching profile:', err);
            return res.status(500).json({ message: 'Error fetching profile' });
        }
        res.json(results[0]);
    });
});


// Route to get user-specific policies
app.get('/api/user-policies', isAuthenticated, (req, res) => {
    const userId = req.session.userId;
    const query = `
        SELECT Policy_ID, Policy_Name, Policy_Type, Premium, Coverage_Amount, Start_Date
        FROM Insurance_Policies
        WHERE User_ID = ?
        ORDER BY Start_Date DESC
        LIMIT 7;
    `;

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching user policies:', err);
            return res.status(500).json({ message: 'Server error' });
        }
        res.json(results);
    });
});

// Route to get all user-specific policies
app.get('/api/alluser-policies', isAuthenticated, (req, res) => {
    const userId = req.session.userId;
    const query = `
        SELECT Policy_ID, Policy_Name, Policy_Type, Premium, Coverage_Amount, Start_Date
        FROM Insurance_Policies
        WHERE User_ID = ?
        ORDER BY Start_Date DESC
    `;

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching user policies:', err);
            return res.status(500).json({ message: 'Server error' });
        }
        res.json(results);
    });
});



// Route to get user-specific claims with merged policy details
app.get('/api/user-claims', isAuthenticated, (req, res) => {
    const query = `
        SELECT 
            c.Claim_ID, c.Policy_ID, c.User_ID, c.Claim_Date, c.Claim_Amount, c.Description, c.Status,
            CONCAT(p.Policy_Name, ' - ', p.Policy_Type) AS Merged_Policy_Name
        FROM claims c
        JOIN insurance_policies p ON c.Policy_ID = p.Policy_ID
        WHERE c.User_ID = ?
    `;
    
    db.query(query, [req.session.userId], (err, results) => {
        if (err) {
            console.error('Error fetching claims:', err);
            return res.status(500).json({ message: 'Error fetching claims' });
        }
        res.json(results);
    });
});


// Route to get user-specific payments
app.get('/api/user-payments', isAuthenticated, (req, res) => {
    const query = `
        SELECT p.Policy_Name, pay.Payment_Amount, pay.Payment_Date, pay.Payment_Method 
        FROM Payments pay
        JOIN Insurance_Policies p ON pay.Policy_ID = p.Policy_ID
        WHERE pay.User_ID = ?
    `;

    db.query(query, [req.session.userId], (err, results) => {
        if (err) {
            console.error('Error fetching payments:', err);
            return res.status(500).json({ message: 'Error fetching payments' });
        }
        res.json(results);
    });
});

// Fetch specific policy details
app.get('/api/policy-details', (req, res) => {
    const policyId = req.query.policy_id;

    const query = 'SELECT * FROM Insurance_Policies WHERE Policy_ID = ?';
    db.query(query, [policyId], (err, results) => {
        if (err) {
            console.error('Error fetching policy details:', err);
            return res.status(500).json({ message: 'Server error' });
        }

        if (results.length > 0) {
            res.json(results[0]);
        } else {
            res.status(404).json({ message: 'Policy not found' });
        }
    });
});
// Fetch user's active policies to file a claim against
app.get('/api/user-policies', isAuthenticated, (req, res) => {
    const query = `SELECT Policy_ID, Policy_Name FROM insurance_policies WHERE User_ID = ?`;
    db.query(query, [req.session.userId], (err, results) => {
        if (err) {
            console.error('Error fetching user policies:', err);
            return res.status(500).json({ message: 'Error fetching policies' });
        }
        res.json(results);
    });
});

// Submit a new claim
app.post('/api/submit-claim', isAuthenticated, (req, res) => {
    const { policyId, claimAmount, description } = req.body;
    const userId = req.session.userId;

    if (!policyId || !claimAmount || !description) {
        return res.status(400).json({ message: 'Please fill in all fields' });
    }

    const insertClaimQuery = `
        INSERT INTO claims (Policy_ID, User_ID, Claim_Date, Claim_Amount, Description, Status)
        VALUES (?, ?, NOW(), ?, ?, 'Pending')
    `;

    db.query(insertClaimQuery, [policyId, userId, claimAmount, description], (err, result) => {
        if (err) {
            console.error('Error submitting claim:', err);
            return res.status(500).json({ message: 'Error submitting claim' });
        }
        res.status(201).json({ message: 'Claim submitted successfully' });
    });
});


// Save security questions
app.post('/api/save-questions', (req, res) => {
    const { question1, question2, question3 } = req.body;
    const userId = req.session.userId;

    if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
    }

    const query = 'INSERT INTO User_Questions (User_ID, Question1, Question2, Question3) VALUES (?, ?, ?, ?)';
    const values = [userId, question1, question2, question3];

    db.query(query, values, (err, result) => {
        if (err) {
            console.error('Error saving security questions:', err);
            return res.status(500).json({ message: 'Error saving security questions' });
        }

        res.status(201).json({ message: 'Security questions saved successfully', redirect: '/dashboard.html' });
    });
});

// Route to verify answers to security questions
app.post('/api/verify-questions', (req, res) => {
    const { email, question1, question2, question3 } = req.body;

    const query = 'SELECT * FROM User_Questions JOIN Users ON User_Questions.User_ID = Users.User_ID WHERE Users.Email = ?';
    db.query(query, [email], (err, results) => {
        if (err) {
            console.error('Error fetching security questions:', err);
            return res.status(500).json({ message: 'Server error' });
        }

        if (results.length > 0) {
            const storedQuestions = results[0];
            if (
                storedQuestions.Question1 === question1 &&
                storedQuestions.Question2 === question2 &&
                storedQuestions.Question3 === question3
            ) {
                res.json({ success: true });
            } else {
                res.json({ success: false });
            }
        } else {
            res.status(404).json({ message: 'User not found' });
        }
    });
});


// Route to handle password reset
app.post('/api/reset-password', async (req, res) => {
    const { email, newPassword } = req.body;

    try {
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        const query = 'UPDATE Users SET Password = ? WHERE Email = ?';
        
        db.query(query, [hashedPassword, email], (err, result) => {
            if (err) {
                console.error('Error updating password:', err);
                return res.status(500).json({ message: 'Server error' });
            }
            res.json({ message: 'Password updated successfully' });
        });
    } catch (error) {
        console.error('Error hashing password:', error);
        res.status(500).json({ message: 'Server error' });
    }
});




app.post('/api/pay-now', isAuthenticated, (req, res) => {
    const { policyId, paymentAmount, paymentMethod } = req.body;
    const userId = req.session.userId;

    if (!policyId || !paymentAmount || !paymentMethod) {
        return res.status(400).json({ message: 'Invalid input data' });
    }

    const paymentQuery = `
        INSERT INTO payments (Policy_ID, User_ID, Payment_Amount, Payment_Date, Payment_Method) 
        VALUES (?, ?, ?, NOW(), ?)
    `;

    const userPaymentsQuery = `
        INSERT INTO user_payments (User_ID, Payment_ID, Payment_Amount, Payment_Date)
        VALUES (?, ?, ?, NOW())
    `;

    // Start a transaction to ensure consistency
    db.beginTransaction((err) => {
        if (err) {
            return res.status(500).json({ message: 'Transaction error' });
        }

        // Step 1: Insert the payment record into the `payments` table
        db.query(paymentQuery, [policyId, userId, paymentAmount, paymentMethod], (err, paymentResult) => {
            if (err) {
                return db.rollback(() => {
                    console.error('Error inserting payment:', err);
                    return res.status(500).json({ message: 'Error processing payment' });
                });
            }

            const paymentId = paymentResult.insertId;

            // Step 2: Insert into the `user_payments` table
            db.query(userPaymentsQuery, [userId, paymentId, paymentAmount], (err) => {
                if (err) {
                    return db.rollback(() => {
                        console.error('Error inserting into user_payments:', err);
                        return res.status(500).json({ message: 'Error recording payment history' });
                    });
                }

                // Commit the transaction if all queries succeed
                db.commit((err) => {
                    if (err) {
                        return db.rollback(() => {
                            console.error('Error committing transaction:', err);
                            return res.status(500).json({ message: 'Transaction commit error' });
                        });
                    }
                    res.status(200).json({ message: 'Payment successful' });
                });
            });
        });
    });
});

// Route to get user payment history
app.get('/api/payment-history', isAuthenticated, (req, res) => {
    const userId = req.session.userId;

    const query = `
        SELECT 
            p.Policy_Name, 
            p.Policy_Type,
            pay.Payment_Amount, 
            pay.Payment_Date, 
            pay.Payment_Method, 
            up.Payment_Amount AS User_Paid_Amount, 
            up.Payment_Date AS User_Payment_Date 
        FROM user_payments up
        JOIN payments pay ON up.Payment_ID = pay.Payment_ID
        JOIN insurance_policies p ON pay.Policy_ID = p.Policy_ID
        WHERE up.User_ID = ?
        ORDER BY up.Payment_Date DESC
    `;

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching payment history:', err);
            return res.status(500).json({ message: 'Error fetching payment history' });
        }
        res.json(results);
    });
});


// Route to register insurance with terms and conditions
app.post('/register-insurance', (req, res) => {
    const { userId, policyName, policyType, premium, coverageAmount, startDate, endDate } = req.body;

    if (!userId || !policyName || !policyType || !premium || !coverageAmount || !startDate || !endDate) {
        return res.status(400).json({ message: 'All fields are required.' });
    }

    // Step 1: Fetch terms and conditions based on policy and insurance type
    const termsQuery = `
        SELECT Terms 
        FROM TermsAndConditions 
        WHERE Insurance_Type = ? AND Policy_Type = ?
    `;

    db.query(termsQuery, [policyName, policyType], (err, results) => {
        if (err) {
            console.error('Error fetching terms and conditions:', err);
            return res.status(500).json({ message: 'Server error.' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'Terms and conditions not found.' });
        }

        const terms = results[0].Terms;

        // Step 2: Insert into the insurance_policies table
        const insertPolicyQuery = `
            INSERT INTO insurance_policies  (Policy_Name, Policy_Type, Premium, Coverage_Amount, Start_Date, End_Date, Terms_Conditions)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

        db.query(insertPolicyQuery, [policyName, policyType, premium, coverageAmount, startDate, endDate, terms], (err, policyResult) => {
            if (err) {
                console.error('Error registering insurance:', err);
                return res.status(500).json({ message: 'Server error.' });
            }

            const policyId = policyResult.insertId; // Get the ID of the newly inserted policy

            // Step 3: Insert into the user_policies table
            const insertUserPolicyQuery = `
                INSERT INTO user_policies (User_ID, Policy_ID, Start_Date, End_Date, Status)
                VALUES (?, ?, ?, ?, 'Pending')
            `;

            db.query(insertUserPolicyQuery, [userId, policyId, startDate, endDate], (err) => {
                if (err) {
                    console.error('Error inserting into user_policies:', err);
                    return res.status(500).json({ message: 'Server error.' });
                }

                res.status(201).json({ message: 'Insurance registered successfully and linked to user.' });
            });
        });
    });
});


// Route to fetch terms and conditions based on Policy Name and Policy Type
app.get('/api/terms-and-conditions', (req, res) => {
    const { policyName, policyType } = req.query;

    if (!policyName || !policyType) {
        return res.status(400).json({ error: "Policy name and type are required." });
    }

    const query = `
        SELECT Terms 
        FROM TermsAndConditions 
        WHERE Insurance_Type = ? AND Policy_Type = ?;
    `;

    db.query(query, [policyName, policyType], (err, results) => {
        if (err) {
            console.error("Database query error:", err);
            return res.status(500).json({ error: "Failed to fetch terms and conditions." });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: "No terms and conditions found for the selected policy." });
        }

        res.json({ terms: results[0].Terms });
    });
});




// Route to submit a cancellation request
app.post('/api/request-cancel', isAuthenticated, (req, res) => {
    const userId = req.session.userId;
    const { policyId, reason } = req.body;

    if (!policyId || !reason) {
        return res.status(400).json({ message: 'Invalid input data' });
    }

    const query = `
        INSERT INTO cancellation_requests (User_ID, Policy_ID, Reason)
        VALUES (?, ?, ?)
    `;

    db.query(query, [userId, policyId, reason], (err, result) => {
        if (err) {
            console.error('Error submitting cancellation request:', err);
            return res.status(500).json({ message: 'Server error' });
        }
        res.status(201).json({ message: 'Cancellation request submitted successfully' });
    });
});

// Route to get user's cancellation requests
app.get('/api/user-cancel-requests', isAuthenticated, (req, res) => {
    const userId = req.session.userId;
    const query = `
        SELECT cr.Request_ID, p.Policy_Name, cr.Request_Date, cr.Status, cr.Reason 
        FROM cancellation_requests cr 
        JOIN Insurance_Policies p ON cr.Policy_ID = p.Policy_ID
        WHERE cr.User_ID = ?
    `;

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching cancellation requests:', err);
            return res.status(500).json({ message: 'Server error' });
        }
        res.json(results);
    });
});

// Route to get user-specific cancellation requests
app.get('/api/cancel-requests', isAuthenticated, (req, res) => {
    const userId = req.session.userId;

    const query = `
        SELECT cr.Request_ID, p.Policy_Name, p.Policy_Type, cr.Reason, cr.Status, cr.Request_Date
        FROM cancellation_requests cr
        JOIN Insurance_Policies p ON cr.Policy_ID = p.Policy_ID
        WHERE cr.User_ID = ?
    `;

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching cancellation requests:', err);
            return res.status(500).json({ message: 'Server error' });
        }
        res.json(results);
    });
});
//Chatbot request
app.post("/api/faq", (req, res) => {
    const userQuery = req.body.query;
    const sql = `
        SELECT Answer 
        FROM FAQs 
        WHERE MATCH(Question) AGAINST(? IN NATURAL LANGUAGE MODE)
        LIMIT 1;
    `;
    db.query(sql, [userQuery], (err, results) => {
        if (err) {
            console.error("Error fetching FAQ:", err);
            return res.status(500).json({ message: "Error fetching FAQ" });
        }
        res.json({ answer: results[0]?.Answer || "I'm sorry, I couldn't find an answer to that." });
    });
});

// Route to delete a specific cancellation request
app.delete('/api/cancel-requests/:requestId', isAuthenticated, (req, res) => {
    const requestId = req.params.requestId;
    const userId = req.session.userId;

    const query = `
        DELETE FROM cancellation_requests
        WHERE Request_ID = ? AND User_ID = ?
    `;

    db.query(query, [requestId, userId], (err, results) => {
        if (err) {
            console.error('Error deleting cancellation request:', err);
            return res.status(500).json({ message: 'Server error' });
        }
        if (results.affectedRows === 0) {
            return res.status(404).json({ message: 'Cancellation request not found or unauthorized.' });
        }
        res.json({ message: 'Cancellation request deleted successfully.' });
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
