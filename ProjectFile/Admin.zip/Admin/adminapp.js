const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const db = require('./admindb'); // Database connection
const app = express();

app.use(express.json());
app.use(express.static('public'));
app.use('/locales', express.static('locales'));

const PORT = 3003;

// Configure express-session
app.use(
    session({
        secret: 'mIqdqG289YXmNoaNk04X2', // Replace with a strong secret key
        resave: false,
        saveUninitialized: false,
        cookie: { secure: false } // Set to true if using HTTPS
    })
);

// Basic route to check server status
app.get('/', (req, res) => {
    res.send('Server is running and connected to the database!');
});

/* ------------------ Admin API Endpoints ------------------ */
app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;

    // Fetch the admin user from the database
    const query = 'SELECT * FROM insuredatabase_admins WHERE Username = ?';
    db.query(query, [username], async (err, results) => {
        if (err) return res.status(500).send('Database error');

        // If no user found
        if (results.length === 0) {
            return res.status(401).send({ message: 'Invalid username or password' });
        }

        const admin = results[0];

        // Compare the password with the hashed password
        const match = await bcrypt.compare(password, admin.Password);
        if (!match) {
            return res.status(401).send({ message: 'Invalid username or password' });
        }

        // Save the user session
        req.session.user = { id: admin.Admin_ID, role: admin.Role };

        res.send({ message: 'Login successful' });
    });
});

app.post('/api/admin-register', async (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ message: 'Username, password, and email are required.' });
    }

    try {
        const checkQuery = 'SELECT * FROM insuredatabase_admins WHERE Username = ? OR Email = ?';
        db.query(checkQuery, [username, email], async (err, results) => {
            if (err) return res.status(500).json({ message: 'Database error.' });
            if (results.length > 0) {
                return res.status(400).json({ message: 'Username or email already exists.' });
            }

            const hashedPassword = await bcrypt.hash(password, 10);

            const insertQuery = `
                INSERT INTO insuredatabase_admins (Username, Password, Email, Role)
                VALUES (?, ?, ?, 'Admin')
            `;
            db.query(insertQuery, [username, hashedPassword, email], (err) => {
                if (err) return res.status(500).json({ message: 'Error registering admin.' });
                res.status(201).json({ message: 'Admin registered successfully.' });
            });
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error.' });
    }
});


// Admin Logout Route
app.post('/api/admin-logout', (req, res) => {
    if (req.session) {
        // Destroy the session
        req.session.destroy((err) => {
            if (err) {
                return res.status(500).json({ message: 'Logout failed.' });
            }
            res.clearCookie('connect.sid'); // Clear session cookie
            return res.status(200).json({ message: 'Logged out successfully.' });
        });
    } else {
        res.status(400).json({ message: 'No active session to log out.' });
    }
});

/* ------------------------login and sign up stuff above */
// Middleware for Admin Authentication
function isAdmin(req, res, next) {
    if (!req.session || !req.session.user || req.session.user.role !== 'Admin') {
        return res.status(403).json({ message: 'Access forbidden: Admins only.' });
    }
    next();
}


// Protect Dashboard Route
app.use('/adminDashboard.html', isAdmin);



// Get all policies
app.get('/api/admin/policies', isAdmin, (req, res) => {
    const query = 'SELECT * FROM insuredatabase_insurance_policies';
    db.query(query, (err, results) => {
        if (err) return res.status(500).send('Error fetching policies');
        res.json(results);
    });
});

// Add a new policy
app.post('/api/admin/policies', isAdmin, (req, res) => {
    const { policyName, policyType, premium, coverageAmount, startDate, endDate } = req.body;
    const query = `
        INSERT INTO insuredatabase_insurance_policies 
        (Policy_Name, Policy_Type, Premium, Coverage_Amount, Start_Date, End_Date)
        VALUES (?, ?, ?, ?, ?, ?)
    `;
    db.query(query, [policyName, policyType, premium, coverageAmount, startDate, endDate], (err) => {
        if (err) return res.status(500).send('Error adding policy');
        res.send({ message: 'Policy added successfully' });
    });
});

// Delete a policy
app.delete('/api/admin/policies/:id', isAdmin, (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM insuredatabase_insurance_policies WHERE Policy_ID = ?';
    db.query(query, [id], (err) => {
        if (err) return res.status(500).send('Error deleting policy');
        res.send({ message: 'Policy deleted successfully' });
    });
});

// Get all claims
app.get('/api/admin/claims', isAdmin, (req, res) => {
    const query = `
        SELECT c.*, u.First_Name, u.Last_Name
        FROM insuredatabase_claims c
        JOIN insuredatabase_users u ON c.User_ID = u.User_ID
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).send('Error fetching claims');
        res.json(results);
    });
});

// Approve or reject a claim
app.put('/api/admin/claims/:id', isAdmin, (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    if (!['Approved', 'Rejected'].includes(status)) {
        return res.status(400).send('Invalid status value');
    }
    const query = 'UPDATE insuredatabase_claims SET Status = ? WHERE Claim_ID = ?';
    db.query(query, [status, id], (err) => {
        if (err) return res.status(500).send('Error updating claim status');
        res.send({ message: `Claim ${status.toLowerCase()} successfully` });
    });
});

// Fetch all users for the insurance company
app.get('/api/insuranceusers', isAdmin, (req, res) => {
    const query = 'SELECT User_ID, First_Name, Last_Name, Email, Phone_Number, Street, City, Province, Zip, DOB FROM users';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching users:', err);
            return res.status(500).json({ message: 'Error fetching users.' });
        }
        res.json(results);
    });
});
// Fetch user by ID
app.get('/api/insuranceusers/:id', (req, res) => {
    const userId = req.params.id;

    const query = 'SELECT * FROM users WHERE User_ID = ?';
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching user:', err);
            return res.status(500).json({ message: 'Server error.' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'User not found.' });
        }

        res.json(results[0]);
    });
});

app.put('/api/insuranceusers/:id/edit', (req, res) => {
    const userId = req.params.id;
    const updateData = req.body;

    // Validate the request payload
    if (!Object.keys(updateData).length) {
        return res.status(400).json({ message: 'No fields provided for update.' });
    }

    const fields = Object.keys(updateData).map((field) => `${field} = ?`).join(', ');
    const values = Object.values(updateData);
    values.push(userId); // Add user ID as the last parameter

    const query = `UPDATE users SET ${fields} WHERE User_ID = ?`;
    

    db.query(query, values, (err) => {
        if (err) {
            console.error('Error updating user:', err);
            return res.status(500).json({ message: 'Error updating user details.' });
        }
        res.json({ message: 'User updated successfully.' });
    });
});

app.get('/api/userPolicyCoverage/:userId', (req, res) => {
    const userId = req.params.userId;
    const query = `
        SELECT * 
        FROM insurance_policies
        WHERE user_ID = ?
    `;
    
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching user policies:', err);
            return res.status(500).json({ message: 'Server error.' });
        }
        res.json(results);
    });
});


app.get('/api/claims/avg', (req, res) => {
    const query = `
        SELECT u.User_ID, u.First_Name, u.Last_Name, AVG(c.Claim_Amount) AS Avg_Claim_Amount
        FROM users u
        JOIN claims c ON u.User_ID = c.User_ID
        GROUP BY u.User_ID, u.First_Name, u.Last_Name
        HAVING AVG(c.Claim_Amount) > (SELECT AVG(Claim_Amount) FROM claims)
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).send('Error fetching average claims');
        res.json(results);
    });
});


app.get('/api/claims/total', (req, res) => {
    const query = `
        SELECT u.User_ID, u.First_Name, u.Last_Name, 
               (SELECT SUM(c.Claim_Amount) FROM claims c WHERE c.User_ID = u.User_ID) AS Total_Claim_Amount
        FROM users u
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).send('Error fetching total claims');
        res.json(results);
    });
});

app.get('/api/claims/approved', (req, res) => {
    const query = `
        SELECT DISTINCT u.User_ID, u.First_Name, u.Last_Name
        FROM users u
        JOIN claims c ON u.User_ID = c.User_ID
        WHERE c.Status = 'Approved'
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).send('Error fetching approved claims');
        res.json(results);
    });
});


// Fetch all claims
app.get('/api/claims', (req, res) => {
    const query = 'SELECT * FROM claims';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching claims:', err);
            return res.status(500).json({ message: 'Error fetching claims.' });
        }
        res.json(results);
    });
});

// Update claim status or amount
app.put('/api/claims/:id', (req, res) => {
    const claimId = req.params.id;
    const { status, claimAmount } = req.body;

    if (!status && !claimAmount) {
        return res.status(400).json({ message: 'Either status or claim amount is required.' });
    }

    let query = 'UPDATE claims SET ';
    const queryParams = [];

    if (status) {
        query += 'Status = ? ';
        queryParams.push(status);
    }
    if (claimAmount) {
        if (queryParams.length > 0) query += ', ';
        query += 'Claim_Amount = ? ';
        queryParams.push(claimAmount);
    }

    query += 'WHERE Claim_ID = ?';
    queryParams.push(claimId);

    db.query(query, queryParams, (err) => {
        if (err) {
            console.error('Error updating claim:', err);
            return res.status(500).json({ message: 'Error updating claim.' });
        }
        res.json({ message: 'Claim updated successfully.' });
    });
});
// Fetch claims by user ID
app.get('/api/claims/user/:id', (req, res) => {
    const userId = req.params.id;
    const query = 'SELECT * FROM claims WHERE User_ID = ?';

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching claims:', err);
            return res.status(500).json({ message: 'Error fetching claims.' });
        }
        res.json(results);
    });
});
app.get('/api/cancellation-requests', (req, res) => {
    const query = 'SELECT * FROM cancellation_requests';

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching cancellation requests:', err);
            return res.status(500).json({ message: 'Error fetching cancellation requests.' });
        }

        res.json(results);
    });
});
app.put('/api/cancellation-requests/:id', (req, res) => {
    const requestId = req.params.id;
    const { status } = req.body;

    if (!status) {
        return res.status(400).json({ message: 'Status is required.' });
    }

    // Fetch the related policy ID and user policy ID from the cancellation request
    const fetchRequestQuery = 'SELECT Policy_ID, User_ID FROM cancellation_requests WHERE Request_ID = ?';

    db.query(fetchRequestQuery, [requestId], (err, results) => {
        if (err) {
            console.error('Error fetching cancellation request:', err);
            return res.status(500).json({ message: 'Error fetching cancellation request.' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'Cancellation request not found.' });
        }

        const { Policy_ID, User_ID } = results[0];

        // Update the status of the cancellation request
        const updateRequestQuery = 'UPDATE cancellation_requests SET Status = ? WHERE Request_ID = ?';

        db.query(updateRequestQuery, [status, requestId], (err) => {
            if (err) {
                console.error('Error updating cancellation request:', err);
                return res.status(500).json({ message: 'Error updating cancellation request.' });
            }

            if (status === 'Approved') {
                // Update the policy status in the user_policies table
                const updatePolicyStatusQuery = `
                    UPDATE user_policies
                    SET Status = 'Cancelled'
                    WHERE User_ID = ? AND Policy_ID = ?
                `;

                db.query(updatePolicyStatusQuery, [User_ID, Policy_ID], (err) => {
                    if (err) {
                        console.error('Error updating policy status:', err);
                        return res.status(500).json({ message: 'Error updating policy status.' });
                    }

                    res.json({ message: 'Cancellation request approved and policy status updated to Cancelled.' });
                });
            } else {
                // If the status is not Approved, just update the cancellation request status
                res.json({ message: `Cancellation request updated to ${status}.` });
            }
        });
    });
});



// Fetch users with claims or payments
app.get('/api/users-with-claims-or-payments', (req, res) => {
    const query = `
        SELECT u.User_ID, u.First_Name, u.Last_Name
        FROM users u
        JOIN claims c ON u.User_ID = c.User_ID
        UNION
        SELECT u.User_ID, u.First_Name, u.Last_Name
        FROM users u
        JOIN payments p ON u.User_ID = p.User_ID
    `;
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching users with claims or payments:', err);
            return res.status(500).send('Error fetching users with claims or payments');
        }
        res.json(results);
    });
});


app.get('/api/admin/user-policies/:userId', (req, res) => {
    const userId = req.params.userId;

    const query = `
        SELECT 
            up.User_Policy_ID, up.User_ID, up.Policy_ID, up.Start_Date, up.End_Date, up.Status,
            ip.Policy_Name, ip.Policy_Type, ip.Premium, ip.Coverage_Amount
        FROM user_policies up
        JOIN insurance_policies ip ON up.Policy_ID = ip.Policy_ID
        WHERE up.User_ID = ?
    `;

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching user policies:', err);
            return res.status(500).json({ message: 'Server error.' });
        }

        res.json(results);
    });
});

app.put('/api/admin/update-policy/:id', (req, res) => {
    const userPolicyId = req.params.id;
    const { status, coverageAmount } = req.body;

    // Check if both fields are provided
    if (!status || !coverageAmount) {
        return res.status(400).json({ message: 'Both status and coverage amount are required.' });
    }

    const updateUserPoliciesQuery = `
        UPDATE user_policies
        SET Status = ?
        WHERE User_Policy_ID = ?
    `;

    const updateInsurancePoliciesQuery = `
        UPDATE insurance_policies
        SET Coverage_Amount = ?
        WHERE Policy_ID = (SELECT Policy_ID FROM user_policies WHERE User_Policy_ID = ?)
    `;

    // Update status in user_policies
    db.query(updateUserPoliciesQuery, [status, userPolicyId], (err) => {
        if (err) {
            console.error('Error updating user policy:', err);
            return res.status(500).json({ message: 'Error updating user policy status.' });
        }

        // Update coverage amount in insurance_policies
        db.query(updateInsurancePoliciesQuery, [coverageAmount, userPolicyId], (err) => {
            if (err) {
                console.error('Error updating coverage amount:', err);
                return res.status(500).json({ message: 'Error updating coverage amount.' });
            }

            res.status(200).json({ message: 'Policy updated successfully.' });
        });
    });
});







// Add a new user
app.post('/api/admin/users', isAdmin, (req, res) => {
    const { firstName, lastName, email, role } = req.body;
    const query = `
        INSERT INTO insuredatabase_users (First_Name, Last_Name, Email, Role)
        VALUES (?, ?, ?, ?)
    `;
    db.query(query, [firstName, lastName, email, role], (err) => {
        if (err) return res.status(500).send('Error adding user');
        res.send({ message: 'User added successfully' });
    });
});

// Delete a user
app.delete('/api/admin/users/:id', isAdmin, (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM insuredatabase_users WHERE User_ID = ?';
    db.query(query, [id], (err) => {
        if (err) return res.status(500).send('Error deleting user');
        res.send({ message: 'User deleted successfully' });
    });
});

// Handle cancellation requests
app.get('/api/admin/cancellations', isAdmin, (req, res) => {
    const query = 'SELECT * FROM insuredatabase_cancellation_requests';
    db.query(query, (err, results) => {
        if (err) return res.status(500).send('Error fetching cancellation requests');
        res.json(results);
    });
});

app.put('/api/admin/cancellations/:id', isAdmin, (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const query = 'UPDATE insuredatabase_cancellation_requests SET Status = ? WHERE Request_ID = ?';
    db.query(query, [status, id], (err) => {
        if (err) return res.status(500).send('Error updating cancellation request');
        res.send({ message: `Request ${status.toLowerCase()} successfully` });
    });
});

/* ------------------ End of API Endpoints ------------------ */

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

